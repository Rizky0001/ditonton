package com.example.ditonton

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
